chrome.runtime.onInstalled.addListener(() => {
  console.log("全网弹幕插件已安装！");
});
  